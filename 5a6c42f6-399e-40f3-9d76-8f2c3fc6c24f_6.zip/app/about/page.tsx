'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function About() {
  const milestones = [
    { year: '2023', title: 'Bot Creation', description: 'Chill Pill Bot was first developed with basic moderation features' },
    { year: '2024', title: 'Feature Expansion', description: 'Added music, economy, and gaming systems to enhance user experience' },
    { year: '2024', title: '10K+ Servers', description: 'Reached over 10,000 Discord servers with 250,000+ active users' },
    { year: '2024', title: 'Advanced Features', description: 'Implemented advanced social commands and utility functions' }
  ];

  const features = [
    { icon: 'ri-shield-check-fill', title: 'Reliable Moderation', description: 'Advanced moderation tools to maintain server order and safety' },
    { icon: 'ri-music-fill', title: 'High-Quality Music', description: 'Crystal clear audio streaming with smart queue management' },
    { icon: 'ri-gamepad-fill', title: 'Interactive Games', description: 'Engaging multiplayer games to build community connections' },
    { icon: 'ri-time-fill', title: '99.9% Uptime', description: 'Reliable service with minimal downtime and fast response times' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="py-20 relative"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=professional%20developer%20workspace%20with%20multiple%20monitors%20showing%20Discord%20bot%20development%2C%20modern%20office%20setup%20with%20purple%20and%20blue%20ambient%20lighting%2C%20code%20editor%20screens%2C%20gaming%20peripherals%2C%20minimalist%20design%2C%20tech%20entrepreneur%20workspace%2C%20high-end%20developer%20setup&width=1920&height=800&seq=about-hero&orientation=landscape')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/90 via-blue-900/80 to-transparent"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">About Chill Pill Bot</h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
              Created with passion to enhance Discord communities worldwide. Learn about our mission, values, and the story behind the bot.
            </p>
          </div>
        </div>
      </section>

      {/* Creator Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 md:p-12 border border-white/10">
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <h2 className="text-4xl font-bold text-white mb-6">Meet the Creator</h2>
                  <h3 className="text-2xl font-semibold text-purple-400 mb-4">Ansh</h3>
                  <p className="text-gray-300 leading-relaxed mb-6">
                    Hi! I'm Ansh, the creator and developer behind Chill Pill Bot. As a passionate developer and Discord enthusiast, I created this bot to solve real problems that Discord communities face every day.
                  </p>
                  <p className="text-gray-300 leading-relaxed mb-6">
                    What started as a simple moderation tool has evolved into a comprehensive Discord bot with over 50 commands spanning moderation, music, games, economy, and social features. My goal is to make Discord servers more engaging, organized, and fun for everyone.
                  </p>
                  <p className="text-gray-300 leading-relaxed">
                    I'm constantly working on new features and improvements based on community feedback. Every update brings us closer to creating the perfect Discord companion for your server.
                  </p>
                </div>
                <div className="text-center">
                  <div 
                    className="w-64 h-64 mx-auto rounded-2xl mb-6 bg-gradient-to-br from-purple-500 to-blue-500"
                    style={{
                      backgroundImage: `url('https://readdy.ai/api/search-image?query=professional%20young%20software%20developer%20portrait%2C%20confident%20smile%2C%20modern%20casual%20clothing%2C%20tech%20startup%20environment%2C%20friendly%20approachable%20developer%2C%20clean%20background%2C%20professional%20headshot%20style%2C%20software%20engineer%20portrait&width=400&height=400&seq=creator-photo&orientation=squarish')`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center'
                    }}
                  ></div>
                  <div className="flex justify-center space-x-4">
                    <a href="#" className="w-10 h-10 flex items-center justify-center bg-gradient-to-r from-purple-500 to-blue-500 rounded-full text-white hover:scale-110 transition-transform cursor-pointer">
                      <i className="ri-github-fill"></i>
                    </a>
                    <a href="#" className="w-10 h-10 flex items-center justify-center bg-gradient-to-r from-purple-500 to-blue-500 rounded-full text-white hover:scale-110 transition-transform cursor-pointer">
                      <i className="ri-twitter-fill"></i>
                    </a>
                    <a href="#" className="w-10 h-10 flex items-center justify-center bg-gradient-to-r from-purple-500 to-blue-500 rounded-full text-white hover:scale-110 transition-transform cursor-pointer">
                      <i className="ri-discord-fill"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-black/20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-white mb-8">Our Mission</h2>
            <p className="text-xl text-gray-300 leading-relaxed mb-12">
              To create the most comprehensive, reliable, and user-friendly Discord bot that empowers communities to thrive. We believe that every Discord server deserves access to powerful tools that enhance communication, entertainment, and management.
            </p>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                  <div className="w-12 h-12 flex items-center justify-center bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl mx-auto mb-4">
                    <i className={`${feature.icon} text-white text-xl`}></i>
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-3">{feature.title}</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Journey Timeline */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-white text-center mb-12">Our Journey</h2>
            
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex items-center space-x-6">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-r from-purple-500 to-blue-500 rounded-full text-white font-bold text-lg">
                      {milestone.year}
                    </div>
                  </div>
                  <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 flex-1 border border-white/10">
                    <h3 className="text-xl font-semibold text-white mb-2">{milestone.title}</h3>
                    <p className="text-gray-300">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-white mb-8">Our Values</h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8">
                <div className="w-12 h-12 flex items-center justify-center bg-white rounded-xl mx-auto mb-4">
                  <i className="ri-community-fill text-purple-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">Community First</h3>
                <p className="text-white/90">Every feature is designed with the community in mind, fostering better connections and experiences.</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8">
                <div className="w-12 h-12 flex items-center justify-center bg-white rounded-xl mx-auto mb-4">
                  <i className="ri-rocket-fill text-purple-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">Innovation</h3>
                <p className="text-white/90">Constantly evolving and improving based on user feedback and emerging technologies.</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8">
                <div className="w-12 h-12 flex items-center justify-center bg-white rounded-xl mx-auto mb-4">
                  <i className="ri-shield-check-fill text-purple-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">Reliability</h3>
                <p className="text-white/90">Providing stable, secure, and consistent service that communities can depend on.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}