'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

export default function Commands() {
  const [activeCategory, setActiveCategory] = useState('moderation');

  const categories = [
    { id: 'moderation', name: 'Moderation', icon: 'ri-shield-check-fill', color: 'from-red-500 to-pink-500' },
    { id: 'music', name: 'Music', icon: 'ri-music-fill', color: 'from-green-500 to-teal-500' },
    { id: 'economy', name: 'Economy', icon: 'ri-coins-fill', color: 'from-yellow-500 to-orange-500' },
    { id: 'games', name: 'Games', icon: 'ri-gamepad-fill', color: 'from-purple-500 to-indigo-500' },
    { id: 'social', name: 'Social', icon: 'ri-heart-fill', color: 'from-pink-500 to-rose-500' },
    { id: 'utility', name: 'Utility', icon: 'ri-tools-fill', color: 'from-blue-500 to-cyan-500' },
    { id: 'information', name: 'Information', icon: 'ri-information-fill', color: 'from-indigo-500 to-purple-500' },
    { id: 'fun', name: 'Fun', icon: 'ri-emotion-happy-fill', color: 'from-orange-500 to-red-500' }
  ];

  const commands = {
    moderation: [
      { command: '_ban <user> [reason]', description: 'Ban a member from the server' },
      { command: '_kick <user> [reason]', description: 'Kick a member from the server' },
      { command: '_warn <user> [reason]', description: 'Warn a member' },
      { command: '_mute <user> [duration] [reason]', description: 'Mute a member for specified duration' },
      { command: '_unmute <user> [reason]', description: 'Unmute a member' },
      { command: '_clear <amount> [user]', description: 'Clear specified number of messages' },
      { command: '_slowmode <seconds>', description: 'Set channel slowmode in seconds' },
      { command: '_lock [channel]', description: 'Lock a channel to prevent messaging' },
      { command: '_unlock [channel]', description: 'Unlock a previously locked channel' }
    ],
    music: [
      { command: '_play <song>', description: 'Play music from YouTube' },
      { command: '_queue', description: 'Show the current music queue' },
      { command: '_skip', description: 'Skip the current song' },
      { command: '_stop', description: 'Stop music and clear the queue' },
      { command: '_nowplaying', description: 'Show information about current song' },
      { command: '_shuffle', description: 'Shuffle the music queue' },
      { command: '_clear_queue', description: 'Clear the entire music queue' },
      { command: '_disconnect', description: 'Disconnect bot from voice channel' }
    ],
    economy: [
      { command: '_balance [user]', description: 'Check coin balance for user' },
      { command: '_daily', description: 'Claim your daily reward' },
      { command: '_work', description: 'Work to earn coins' },
      { command: '_beg', description: 'Beg for coins from other users' },
      { command: '_rob <user>', description: 'Attempt to rob another user (risky!)' },
      { command: '_shop', description: 'View the item shop' },
      { command: '_buy <item>', description: 'Buy an item from the shop' },
      { command: '_inventory [user]', description: 'View user inventory' }
    ],
    games: [
      { command: '_rps <choice>', description: 'Play Rock Paper Scissors' },
      { command: '_dice [sides] [count]', description: 'Roll dice with specified sides and count' },
      { command: '_coinflip [bet]', description: 'Flip a coin with optional betting' },
      { command: '_trivia', description: 'Answer trivia questions' },
      { command: '_hangman', description: 'Play a game of hangman' },
      { command: '_tictactoe <opponent>', description: 'Play Tic Tac Toe against another user' },
      { command: '_connect4 <opponent>', description: 'Play Connect 4 against another user' },
      { command: '_blackjack [bet]', description: 'Play blackjack with optional betting' },
      { command: '_slots [bet]', description: 'Play slot machine with optional betting' },
      { command: '_lottery <numbers>', description: 'Play the lottery with chosen numbers' }
    ],
    social: [
      { command: '_marry <user>', description: 'Propose marriage to another user' },
      { command: '_divorce your spouse', description: 'Divorce your current spouse' },
      { command: '_spouse [user]', description: 'Check marriage status of user' },
      { command: '_hug <user>', description: 'Give someone a virtual hug' },
      { command: '_kiss <user>', description: 'Give someone a virtual kiss' },
      { command: '_pat <user>', description: 'Pat someone on the head' },
      { command: '_highfive <user>', description: 'Give someone a high five' },
      { command: '_ship <user1> [user2]', description: 'Calculate relationship compatibility' }
    ],
    utility: [
      { command: '_afk [reason]', description: 'Set yourself as away from keyboard' },
      { command: '_remind <time> <message>', description: 'Set a reminder for specified time' },
      { command: '_poll <question> <options>', description: 'Create a poll with multiple options' },
      { command: '_calculate <expression>', description: 'Perform mathematical calculations' },
      { command: '_base64encode <text>', description: 'Encode text to base64 format' },
      { command: '_base64decode <text>', description: 'Decode base64 text to readable format' },
      { command: '_hash <algorithm> <text>', description: 'Hash text using specified algorithm' },
      { command: '_stealemote <emote> [name]', description: 'Steal an emote from another server' },
      { command: '_stealsticker <url> [name]', description: 'Steal a sticker using URL' }
    ],
    information: [
      { command: '_userinfo [user]', description: 'Get detailed information about a user' },
      { command: '_serverinfo', description: 'Get information about the current server' },
      { command: '_botinfo', description: 'Get information about Chill Pill Bot' },
      { command: '_avatar [user]', description: 'Get user avatar in full resolution' },
      { command: '_triviastats [user]', description: 'Check trivia game statistics' },
      { command: '_ping', description: 'Check bot response time and latency' }
    ],
    fun: [
      { command: '_lovecalc <name1> <name2>', description: 'Calculate love compatibility between two names' },
      { command: '_reverse_text <text>', description: 'Reverse the provided text' },
      { command: '_minesweeper [size]', description: 'Generate a minesweeper game board' }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-6">Bot Commands</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore all the powerful commands available in Chill Pill Bot. Click on any category below to view its commands.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all duration-300 whitespace-nowrap cursor-pointer ${
                activeCategory === category.id
                  ? `bg-gradient-to-r ${category.color} text-white shadow-lg transform scale-105`
                  : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
              }`}
            >
              <div className={`w-5 h-5 flex items-center justify-center ${activeCategory === category.id ? '' : 'opacity-70'}`}>
                <i className={`${category.icon}`}></i>
              </div>
              <span className="font-medium">{category.name}</span>
            </button>
          ))}
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
          <div className="flex items-center space-x-3 mb-8">
            <div className={`w-10 h-10 flex items-center justify-center bg-gradient-to-r ${categories.find(c => c.id === activeCategory)?.color} rounded-xl`}>
              <i className={`${categories.find(c => c.id === activeCategory)?.icon} text-white text-xl`}></i>
            </div>
            <h2 className="text-3xl font-bold text-white">
              {categories.find(c => c.id === activeCategory)?.name} Commands
            </h2>
          </div>

          <div className="grid gap-4">
            {commands[activeCategory as keyof typeof commands]?.map((cmd, index) => (
              <div key={index} className="bg-white/5 rounded-xl p-6 hover:bg-white/10 transition-all duration-200">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex-1">
                    <code className="text-purple-400 text-lg font-mono bg-black/20 px-3 py-1 rounded">
                      {cmd.command}
                    </code>
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-300">{cmd.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-300 mb-6">
            <strong>Syntax Guide:</strong> &lt;required&gt; parameters must be provided, [optional] parameters are not required
          </p>
          <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-6 rounded-xl">
            <h3 className="text-2xl font-bold text-white mb-4">Need Help?</h3>
            <p className="text-white/90 mb-4">
              Join our support server for assistance with commands and bot setup.
            </p>
            <a
              href="/support"
              className="inline-block bg-white text-purple-600 px-6 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-customer-service-2-fill mr-2"></i>
              Get Support
            </a>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}