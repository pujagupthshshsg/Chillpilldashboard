
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function Home() {
  const features = [
    {
      icon: 'ri-shield-check-fill',
      title: 'Moderation',
      description: 'Advanced moderation tools to keep your server safe and organized',
      color: 'from-red-500 to-pink-500'
    },
    {
      icon: 'ri-music-fill',
      title: 'Music',
      description: 'High-quality music streaming with queue management and controls',
      color: 'from-green-500 to-teal-500'
    },
    {
      icon: 'ri-coins-fill',
      title: 'Economy',
      description: 'Engaging economy system with daily rewards, jobs, and shopping',
      color: 'from-yellow-500 to-orange-500'
    },
    {
      icon: 'ri-gamepad-fill',
      title: 'Games',
      description: 'Fun interactive games to keep your community entertained',
      color: 'from-purple-500 to-indigo-500'
    },
    {
      icon: 'ri-heart-fill',
      title: 'Social',
      description: 'Social commands to build relationships and community bonds',
      color: 'from-pink-500 to-rose-500'
    },
    {
      icon: 'ri-tools-fill',
      title: 'Utility',
      description: 'Helpful utility commands for server management and productivity',
      color: 'from-blue-500 to-cyan-500'
    }
  ];

  const stats = [
    { label: 'Servers', value: '10,000+' },
    { label: 'Users', value: '250,000+' },
    { label: 'Commands', value: '50+' },
    { label: 'Uptime', value: '99.9%' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="min-h-screen flex items-center justify-center relative"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20futuristic%20discord%20bot%20dashboard%20interface%20with%20purple%20and%20blue%20neon%20lights%2C%20holographic%20elements%2C%20cyberpunk%20aesthetic%2C%20clean%20minimalist%20design%20with%20floating%20UI%20panels%2C%20digital%20particles%20and%20glow%20effects%2C%20high%20tech%20atmosphere%2C%20professional%20gaming%20setup%20background%2C%20ultra%20wide%20panoramic%20view&width=1920&height=1080&seq=hero-bg&orientation=landscape')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/80 via-blue-900/70 to-transparent"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl">
            <h1 className="text-6xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Chill Pill Bot
              <span className="block text-4xl md:text-5xl bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mt-2">
                Dashboard
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
              The ultimate Discord bot for moderation, music, and fun on your server. Transform your community experience with powerful features and seamless automation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="https://discord.com/oauth2/authorize?client_id=1398200565808369745&permissions=1719636185841655&integration_type=0&scope=bot"
                className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:from-purple-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 text-center whitespace-nowrap cursor-pointer"
              >
                <i className="ri-download-cloud-fill mr-2"></i>
                Invite Chill Pill Bot
              </Link>
              <Link
                href="/commands"
                className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-purple-900 transition-all duration-300 text-center whitespace-nowrap cursor-pointer"
              >
                <i className="ri-list-check mr-2"></i>
                View Commands
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-black/20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-gray-300 text-lg">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Powerful Features</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Discover the comprehensive set of tools and commands that make Chill Pill Bot the perfect addition to your Discord server.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 hover:bg-white/10 transition-all duration-300 border border-white/10">
                <div className={`w-16 h-16 flex items-center justify-center bg-gradient-to-r ${feature.color} rounded-xl mb-6`}>
                  <i className={`${feature.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">{feature.title}</h3>
                <p className="text-gray-300 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of servers already using Chill Pill Bot to enhance their Discord experience.
          </p>
          <Link
            href="https://discord.com/oauth2/authorize?client_id=1398200565808369745&permissions=1719636185841655&integration_type=0&scope=bot"
            className="inline-block bg-white text-purple-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 whitespace-nowrap cursor-pointer"
          >
            <i className="ri-add-circle-fill mr-2"></i>
            Add to Server Now
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
