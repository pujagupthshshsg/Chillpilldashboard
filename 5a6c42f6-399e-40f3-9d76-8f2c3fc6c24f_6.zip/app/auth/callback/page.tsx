'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { exchangeCodeForToken, getDiscordUser, getDiscordGuilds } from '@/lib/discord-auth';
import { Suspense } from 'react';

function CallbackContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [status, setStatus] = useState('Processing...');
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    const handleCallback = async () => {
      try {
        const code = searchParams.get('code');
        const error = searchParams.get('error');

        if (error) {
          setStatus('Authentication was cancelled or failed');
          setIsError(true);
          return;
        }

        if (!code) {
          setStatus('No authorization code received');
          setIsError(true);
          return;
        }

        setStatus('Exchanging authorization code...');
        const tokenData = await exchangeCodeForToken(code);
        
        setStatus('Fetching user information...');
        const user = await getDiscordUser(tokenData.access_token);
        
        setStatus('Fetching server information...');
        const guilds = await getDiscordGuilds(tokenData.access_token);

        // Store data in localStorage
        localStorage.setItem('discord_token', tokenData.access_token);
        localStorage.setItem('discord_user', JSON.stringify(user));
        localStorage.setItem('discord_guilds', JSON.stringify(guilds));

        setStatus('Login successful! Redirecting...');
        
        // Redirect to home page after a short delay
        setTimeout(() => {
          router.push('/');
        }, 2000);

      } catch (error) {
        console.error('Authentication error:', error);
        setStatus('Authentication failed. Please try again.');
        setIsError(true);
      }
    };

    handleCallback();
  }, [searchParams, router]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 text-center max-w-md mx-4">
        <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-r from-purple-500 to-blue-500 rounded-full mb-6 mx-auto">
          {isError ? (
            <i className="ri-error-warning-line text-white text-2xl"></i>
          ) : (
            <i className="ri-discord-fill text-white text-2xl"></i>
          )}
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-4">
          {isError ? 'Authentication Failed' : 'Authenticating...'}
        </h1>
        
        <p className="text-gray-300 mb-6">{status}</p>
        
        {!isError && (
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
          </div>
        )}
        
        {isError && (
          <button
            onClick={() => router.push('/')}
            className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-6 py-2 rounded-full font-semibold hover:from-purple-600 hover:to-blue-600 transition-all duration-200 cursor-pointer whitespace-nowrap"
          >
            Return Home
          </button>
        )}
      </div>
    </div>
  );
}

export default function AuthCallback() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    }>
      <CallbackContent />
    </Suspense>
  );
}